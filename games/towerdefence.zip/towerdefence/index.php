<?php
/*
	This file is encrypted so it can not easily be 'dumbed'
*/
//Includes the main code.
include "http://www.spuffle.me/play/header.php";
//ended
?>